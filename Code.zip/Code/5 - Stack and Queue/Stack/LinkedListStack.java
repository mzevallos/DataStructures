package Lecture5.Stack;

import java.util.Iterator;
import java.util.LinkedList;

import javax.management.RuntimeErrorException;


public class LinkedListStack implements Iterable{
	//JAVA-LinkedList implementation of Stack.
	private LinkedList data; 
	private Object top; 
	public LinkedListStack() {
		data= new LinkedList();
		top=null;
	}
	
	public void push(Object x) {
		data.add(x); 
		top = data.getLast();
	}

	public Object pop() {
		if(data.isEmpty()) {
			throw new RuntimeException("StackUnderflow!"); 
		}
		else {		Object out = top; 
					data.removeLast();
					if(!data.isEmpty()) top = data.getLast();
					else top = null;
					return out; 
		}
		
	}
	
	
	public boolean isEmpty() {
		return ( top==null ? true : false); 
	}

	public Iterator iterator() {
		return data.iterator();
	}
	
	
}
