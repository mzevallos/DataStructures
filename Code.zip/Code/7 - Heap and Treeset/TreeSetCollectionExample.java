

import java.util.*;

public class TreeSetCollectionExample {

	public static void main(String[] args) {
	
		Collection<String> treeCol = new TreeSet<String>(new CompareTreeSet()); 
		treeCol.add("A");
		treeCol.add("C");
		treeCol.add("B");
		treeCol.add("A");
		treeCol.add("E");
		treeCol.add("F");
		//treeCol.add(null);
		
		//verifying if the tree contains an element
		if(treeCol.contains(new String("H"))) 
			System.out.println("The tree contains H");
		else System.out.println("The tree does not contain H");
		
		//converting a collection to array
		Object[] os = treeCol.toArray(); 
		System.out.println("\nThe first element of the array representation of the treeset is: " + (String) os[0]);
		
		//printing elements using an iterator
		System.out.println("\nPrinting the content of the treeset using an iterator:");
		Iterator it = treeCol.iterator(); 
		while(it.hasNext())
			System.out.print(it.next()+" ");
		
		System.out.println("\n\nPrinting the content of the treeset without iterator");
		System.out.println(treeCol);

	}

}
