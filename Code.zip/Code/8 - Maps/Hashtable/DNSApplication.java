

import java.util.*;
public class DNSApplication {
	public static void main(String[] args) {
		Map<String,String> map = new Hashtable<String, String>();
		map.put("www.wiley.com" , "208.215.179.146");
		map.put("http://localhost" , "127.0.0.0");
		map.put("www.google.com" , "64.233.160.0");
		map.put("www.google.com" , "64.233.160.0");
		System.out.println("Printing entryset....");
		Iterator it =null; 
		if(!map.isEmpty()){
			it=  map.entrySet().iterator(); 
			while(it.hasNext()){
				System.out.println(it.next());
			}		
			System.out.println("\n\nPrinting keyset......");		
			it = map.keySet().iterator(); 
			while(it.hasNext()){
				System.out.println(it.next());
			}
		}				
	}
}
