package Lecture_9.Hashmap_Implementation;

import java.util.Iterator;

public class HashmapApplication {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		MyHashmap map = new MyHashmap(); 
		map.put("Tom", "Tom") ;
		map.put("Mary", "Mary"); 
		map.put("Jon", "Jon"); 
		Iterator it = map.entrySet().iterator(); 
		while(it.hasNext()) {
			MyEntry entry = (MyEntry) it.next(); 
			System.out.println("<"+ entry.getKey() + "," +entry.getValue()+ ">");
		}
		
		System.out.println("Searching for Mac ...");
		MyEntry e = (MyEntry) map.get("Mac"); 
		if (e==null) 
			System.out.println("Could not find the record");
		else System.out.println(e.getValue());
		
		System.out.println("Checking containment of Mary and Joe ...");
		System.out.println(map.containsKey("Mary"));
		System.out.println(map.containsKey("Joe"));
		
		System.out.println("ContainsKey Tom...");
		System.out.println(map.containsKey("Tom"));
		
		System.out.println("Size of map is: " + map.size());
		System.out.println("is map empty before calling clear()? " + map.isEmpty());
		map.clear(); 
		System.out.println("is map empty after calling clear()? " + map.isEmpty());
	}

}
