package Lecture_9.Hashmap_Implementation;

import java.util.*;

public class MyHashmap implements Map, Cloneable{
		
		
	private MyBucket[] index; 
	private static final int DEFAULT = 100; 
	private int size= 0; 
	
	public MyHashmap() {
		index  = new MyBucket[DEFAULT];
		for (int i=0; i<index.length; i++)
			index[i] = new MyBucket(i);
	}
	
	public MyHashmap(int capacity) {
		index  = new MyBucket[capacity];
	}
	
	
	private int calcPosition(String k){
		return k.hashCode() % (index.length -1); //this is the index for a bucket.
	}
	
	public Set<String> keySet() { 
		TreeSet<String> keys = new TreeSet<String>(); 
		for(int i=0; i<index.length; i++){
			Set<MyEntry> kTemp = index[i].getElements(); 
			for(MyEntry e : kTemp) 
				keys.add(e.getKey()); 
		}
		return keys;
	}
	
	public Set<MyEntry> entrySet() { 
		TreeSet<MyEntry> entryset = new TreeSet<MyEntry>(); 
		for(int i=0; i<index.length; i++){
			Set<MyEntry> kTemp = index[i].getElements(); 
			if ( kTemp!=null && kTemp.size()>0) 
				entryset.addAll(kTemp);  
		}
		return entryset;
	}
	
	
	public Collection<String> values() { 
		LinkedList<String> values = new LinkedList<String>(); 
		for(int i=0; i<index.length; i++){
			Set<MyEntry> kTemp = index[i].getElements(); 
			for(MyEntry e : kTemp) 
				values.add(e.getValue()); 
		}
		return values;
	}
	
	
	public boolean isEmpty(){
		return (size==0) ?true:false;
	}
	
	
	public MyHashmap clone(){
		MyHashmap answer=  null;
		try{
			answer=  (MyHashmap) super.clone(); 
			answer.index = index.clone(); 
			return answer;
		}
		catch(CloneNotSupportedException e){
			throw new RuntimeException("This class is not Cloneable!"); 
		}
	}
	
	public void clear() {//Removes all the mapping from this map
		for(MyBucket b: index) b=null; 
		size=0;
	}
	

	public int size() {
		return size;
	}

	public boolean containsKey(Object key) {
		MyBucket b = index[calcPosition((String) key)]; 
		MyEntry e=b.getElement((String) key); 
		return (e==null) ? false:true; 
	}

	public boolean containsValue(Object value) {
		//returns true if map has one or more keys to the specified value
		ArrayList<MyEntry> match = new ArrayList<MyEntry>();
		for(MyBucket b: index){
			for(MyEntry e: b.getElements()){
				if(value.equals(e.getValue())){
					match.add(e);
				}
			}
		}
		return (match.size()==0) ? false :true;
	}

	public Object get(Object key) {
		MyBucket b = index[calcPosition((String)key)]; 
		return (b==null) ?null : b.getElement((String)key); 
	}

	public Object put(Object key, Object value) {
		MyEntry oldEntry = ((MyEntry) this.get((String) key)) ;  
		MyEntry e = new MyEntry((String) key, (String) value);
		index[calcPosition((String)key)].add(e); 
		size++; 
		return (oldEntry==null ) ? null : oldEntry.getValue();
	}

	public Object remove(Object key) {
		MyBucket b = index[calcPosition((String)key)]; 
		String value = null;
		value = b.getElement((String) key).getValue(); 
		//remove:
		b.removeElement((String) key);
		size--;
		return value;
	}

	public void putAll(Map m) {
		// TODO Complete this method as an exercise
		
	}
}
