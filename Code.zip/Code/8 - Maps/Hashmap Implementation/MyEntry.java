package Lecture_9.Hashmap_Implementation;

public class MyEntry implements Comparable{
	private String key; 
	private String value; 
	
	public MyEntry (String k, String v){
		key = k;
		value = v;
	}
	
	public void setKey(String k) { key = k; }
	public void setValue(String v) {value = v; }
	
	public String getKey() { return key; }
	public String getValue() {return value; }

	public int compareTo(Object o) {
		if( o instanceof MyEntry){
			MyEntry newEntry = (MyEntry)o; 
			if(newEntry.getKey().compareTo(key)<0) return -1; 
			else if (newEntry.getKey().compareTo(key)>0) return 1;
			else return 0;
		}
		return -2; //invalid comparison
	}
	
} //end of class
