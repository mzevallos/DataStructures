package Lecture_9.Hashmap_Implementation;

import java.util.*;

public class MyBucket {
	private Set<MyEntry> elements; 
	private int key;
	private int num; 
	
	public MyBucket(int k){
		elements = new TreeSet<MyEntry>(); 
		key = k;
	}
	public void add(MyEntry e){
		boolean flag=false;
		Iterator it = elements.iterator(); 
		while(it.hasNext())
			if(e.getKey().equals( ((MyEntry)it.next()).getKey()) ){ 
					flag= true;
					break;
			}
		if (!flag) elements.add(e);
	}
	
	public Set<MyEntry> getElements(){
		return elements;
	}
	
	
	public MyEntry getElement(String key){
		if (elements.isEmpty()) return null; 
		Iterator it = elements.iterator(); 
		while(it.hasNext()){
			MyEntry entry  = (MyEntry)it.next(); 
			if(key.equals( entry.getKey()) )
					return entry; 
		}
		return null;
	}
	
	
	public boolean removeElement(String key){
		if (elements.isEmpty()) return false; 
		for(MyEntry e: elements){
			if (key.equals(e.getKey())) {
				elements.remove(e); 
				return true;
			}
		}
		return false;
	}
	
	 
	
	public int getKey(){
		return key;
	}
	
	
	public int getSize(){
		return num;
	}

}
