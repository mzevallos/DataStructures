
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.swing.JOptionPane;

public class DirectedGraphApplication {
	public static void main(String[] args) {
		DirectedGraph<Character> directed = new DirectedGraph<Character>(null); 
		String menu = "1- Enter vertices \n2-Set an edge \n3-Print dependencies \n4-Get shortest path \n5-Exit";
		while(true){
			int option =-1;
			boolean flag= true;
			do{
				try{
					option =Integer.parseInt(JOptionPane.showInputDialog(menu));
					flag= true;
				}catch(NumberFormatException e){
					JOptionPane.showMessageDialog(null, "Invalid input.");
					flag = false;
				}
			}while(!flag);
			
			switch(option){
				case 1:
					addVertices(directed);
					break;
				case 2:
					setEdge(directed);
					break;
				case 3:
					JOptionPane.showMessageDialog(null, directed.printAdjacencyMatrix(), "Adjacency Matrix", JOptionPane.OK_OPTION);
					break;
				case 4:
					JOptionPane.showMessageDialog(null, getShortestPath(directed), "Shortest Path", JOptionPane.OK_OPTION);
					break;
				case 5:
					System.exit(0);
			}
		}

	}
	
	public static void addVertices(DirectedGraph<Character> graph){
		Character v = new Character(JOptionPane.showInputDialog(null, "Enter a chatacter like 'C'").charAt(0));
		graph.addOrigin(v);
	}

	public static void setEdge(DirectedGraph<Character> graph){
		boolean flag= true;
		do{
			String input = JOptionPane.showInputDialog("Enter two vertices separated by comma, like A,B: \n" +graph.printAdjacencyMatrix());
			try{
				Scanner scan = new Scanner(input);
				scan.useDelimiter(",");
				Character ch1 = scan.next().trim().charAt(0);
				Character ch2 = scan.next().trim().charAt(0);
				graph.setEdge(ch1, ch2);
				flag=true;
			}catch(Exception e){
				flag = false;
			}
		}while(!flag);
	}
	
	public static String getShortestPath(DirectedGraph<Character> graph){
		boolean flag= true;
		String shortest="";
		List<Character> shortestPath=null;
		do{
			String input = JOptionPane.showInputDialog("Enter two vertices separated by comma, like A,B: \n" +graph.printAdjacencyMatrix());
			try{
				Scanner scan = new Scanner(input);
				scan.useDelimiter(",");
				Character source = scan.next().trim().charAt(0);
				Character dest = scan.next().trim().charAt(0);
				shortestPath = graph.getShortestPath(source, dest);
				flag=true;
			}catch(Exception e){
				flag = false;
			}
		}while(!flag);
		if(shortestPath==null || shortestPath.isEmpty()) return null;
		Iterator<Character> it = shortestPath.iterator(); 
		while(it.hasNext()){
			shortest+=it.next()+ ",";
		}
		return shortest;
	}
}
