
import java.util.*;
import javax.swing.JOptionPane;

public class DirectedGraph<E> {
	
	public final static int MAX=100;
	private List<E> origins; 
	private boolean[][] adjacencyMatrix; 
	
	public DirectedGraph(){
		this(null);
	}
	
	public DirectedGraph(List<E> origins){
		if(origins !=null ){
			this.origins = origins;
			adjacencyMatrix = new boolean [origins.size()][origins.size()];
		}
		else this.origins = new ArrayList<E>();
		adjacencyMatrix = new boolean [MAX][MAX];
	}
	
	public void addOrigin(E v){
		origins.add(v);
	}
	
	public List<E> getOrigins(){ return origins;}

	public void setEdge(E v1, E v2){
		//find the index for v1
		int i=origins.indexOf(v1);
		int j= origins.indexOf(v2);
		adjacencyMatrix[i][j] = true;
	}
	
	public String printAdjacencyMatrix(){
		Iterator dest = origins.iterator(); 
		String out=new String("  ");
		while(dest.hasNext()){
			E origin =(E) dest.next();
			out+= origin+" ";
		}
		out+= "\n";
		
		Iterator it = origins.iterator(); 
		for(int i=0; i<origins.size(); i++){
			if(it.hasNext()){
				E origin =(E) it.next();
				out+= origin+" ";
				for(int j=0; j<origins.size();j++){
					
					out+= (!adjacencyMatrix[i][j])? "0 ": "1 ";
				}
				out+= "\n";
			}
			else {
				JOptionPane.showMessageDialog(null, JOptionPane.ERROR_MESSAGE);
				break;
			}
		}
		return out;
	}

	public List<List<E>> getPaths(E source , E dest, Map<E, E> visited){
		List<List<E>> paths = new ArrayList<List<E>>();
		if (visited ==null) 
			visited= new HashMap<E, E>();
		
		List<Integer> adjacentVertices = getAdjacentVertices(source);
		if(adjacentVertices==null || adjacentVertices.isEmpty()) return null;
		Iterator<Integer> ait = adjacentVertices.iterator(); 
		while(ait.hasNext()){
			visited.put(source, source);
			E v =origins.get(ait.next());
			if(!visited.containsKey(v)){
				visited.put(v, v);
				if(v.equals(dest)) { 
					paths.add(new ArrayList<E>( visited.values()));
					visited.clear();
				}
				else{		
					paths.addAll(getPaths(v, dest, visited));
				}
			}
			
		}
		return paths;
	}
	
	
	public List<E> getShortestPath(E source, E dest){
		List<E> shortestPath=null;
		List<List<E>> paths = getPaths(source, dest,null);
		int maxLength=origins.size()-1;
		Iterator<List<E>> it = paths.iterator(); 
		while(it.hasNext()){
			List<E> path = it.next(); 
			if(path.size()-1 < maxLength) {
				shortestPath = path;
				maxLength = path.size()-1;
			}
				
		}
		return shortestPath;
	}
	
	
	/**
	 * 
	 * @param v
	 * @return the indices for adjacent vertices.
	 */
	private List<Integer> getAdjacentVertices(E v){
		int i = origins.indexOf(v);
		if(i==-1) return null;
		List<Integer> adjacentIx=new ArrayList<Integer>(origins.size());
		for(int j=0; j<origins.size(); j++){
			if(adjacencyMatrix[i][j]==true) adjacentIx.add(j);
		}
		return adjacentIx;
	}
}
