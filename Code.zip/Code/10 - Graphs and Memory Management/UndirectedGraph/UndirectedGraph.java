
import java.util.*;

import javax.swing.JOptionPane;

public class UndirectedGraph<E> {
	
	public final static int MAX=100;
	private List<E> origins; 
	private boolean[][] adjacencyMatrix; 
	
	public UndirectedGraph(){
		this(null);
	}
	
	public UndirectedGraph(List<E> origins){
		if(origins !=null ){
			this.origins = origins;
			adjacencyMatrix = new boolean [origins.size()][origins.size()];
		}
		else this.origins = new ArrayList<E>();
		adjacencyMatrix = new boolean [MAX][MAX];
	}
	
	public void addOrigin(E v){
		origins.add(v);
	}
	
	public List<E> getOrigins(){ return origins;}

	public void setEdge(E v1, E v2){
		//find the index for v1
		int i=origins.indexOf(v1);
		int j= origins.indexOf(v2);
		adjacencyMatrix[i][j] = true;
		adjacencyMatrix[j][i]=true;
	}
	
	public String printAdjacencyMatrix(){
		Iterator dest = origins.iterator(); 
		String out=new String("  ");
		while(dest.hasNext()){
			E origin =(E) dest.next();
			out+= origin+" ";
		}
		out+= "\n";
		
		Iterator it = origins.iterator(); 
		for(int i=0; i<origins.size(); i++){
			if(it.hasNext()){
				E origin =(E) it.next();
				out+= origin+" ";
				for(int j=0; j<origins.size();j++){
					
					out+= (!adjacencyMatrix[i][j])? "0 ": "1 ";
				}
				out+= "\n";
			}
			else {
				JOptionPane.showMessageDialog(null, JOptionPane.ERROR_MESSAGE);
				break;
			}
		}
		return out;
	}

	public String getShortestPath(E src, E dst){
		Map<E, E> visited = new HashMap<E, E>();
		visited.put(src,src);
		String shortestPath= process(src, dst, visited);
		return shortestPath;

	}
	
	
	private String  process(E src,E dst, Map<E, E> visited){ 
		if(src.equals(dst)) return dst.toString();
		
		Queue<E> adjacencyList = new LinkedList<E>(); 
		String path = null;
		//add adjacent nodes
		List<Integer> vs = getAdjacentVertices(src);
		boolean flag=false;
		for(Integer index: vs ){
			if(!visited.containsKey(origins.get(index))){
				flag=true;
				E naighbor = origins.get(index);
				visited.put(naighbor, naighbor);
				adjacencyList.add(naighbor);
			}
		}	
		if(!flag) 
			return "";
		
		for(E n: adjacencyList){
			path = src.toString();
			String temp = process(n,dst, visited);
			if (!temp.equals(""))
				path =  path + temp;
			else 
				path = ""; //reset the path
		}
		
		return path;

	}
	
	
	/**
	 * 
	 * @param v
	 * @return the indices for adjacent vertices.
	 */
	private List<Integer> getAdjacentVertices(E v){
		int i = origins.indexOf(v);
		if(i==-1) return null;
		List<Integer> adjacentIx=new ArrayList<Integer>(origins.size());
		for(int j=0; j<origins.size(); j++){
			if(adjacencyMatrix[i][j]==true && adjacencyMatrix[j][i]==true) adjacentIx.add(j);
		}
		return adjacentIx;
	}
}
