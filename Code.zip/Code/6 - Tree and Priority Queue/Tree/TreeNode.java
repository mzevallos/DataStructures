

public class TreeNode {
	private double element; //this is data
	private TreeNode parent; //represents the link to the parent node
	//private TreeNode[] children; //children of this node
	
	private TreeNode left; 
	private TreeNode right; 
	
	//public static final int MAX = 5; 
	private int numChild;
	
	public TreeNode(){
		//children = new TreeNode[MAX];
		numChild=0; 
	}
	
	public void setElement(double element){
		this.element = element; 
	}
	
	public void setLeft(TreeNode l){
		if(left==null){
			numChild++;
		}
		left = l;
	}
	
	public void setRight(TreeNode r){
		if(right==null){
			numChild++;
		}
		right = r; 
	}
	
	public TreeNode getRight() {return right; }
	public TreeNode getLeft() {return left; }
	
	public double getElement() { return element; }
	
	/*
	public boolean addChild(TreeNode child){
		if(numChild >= MAX) return false;
		children[numChild++] = child;
		return true;
	}
	
	public boolean addChildren(TreeNode[] cs){
		if(cs.length+numChild >= MAX) return false;
		for(int i=0 ; i< cs.length; i++){
			children[numChild++] = cs[i];
		}
		return true;
	}
	*/
	
	public void setParent(TreeNode parent){
		this.parent = parent;
	}
	
	public TreeNode getParent(){ return parent; }
	//public TreeNode[] getChildren() { return children; }
	public int getNumChildren() { return numChild; }
	
}
