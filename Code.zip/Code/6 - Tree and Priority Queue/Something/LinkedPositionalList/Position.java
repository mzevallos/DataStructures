package Lecture8.LinkedPositionalList;

public interface Position<E> {
	E getElement() throws IllegalArgumentException; 
}
