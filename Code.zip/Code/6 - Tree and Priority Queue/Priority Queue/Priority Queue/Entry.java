package Lecture8.PQ;

public interface Entry<K,V> {
	public K getKey(); 
	public V getValue();
}
