

public class Process {
	private int id;
	private long interval; 
	private static int number=1000;
	public Process(long i) {
		id = number++;
		interval = i; 
	}
	
	public long getDuration(){ return interval; }
	public int getId() { return id; }
	
}
