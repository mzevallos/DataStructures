

public class PQEntry {
	private long key; 
	private Process val; 
	
	public PQEntry() {}
	
	public void setProcess(Process p){ 
		val = p;
		key= val.getDuration();
	}
	public Process getProcess() { return val; }
	
	public long getKey(){
		return key; 
	}
	
	public String toString() {
		return "process key:" + key + ", value: " + val.getId() + ":" +val.getDuration(); 
	}
}
