

import java.util.*;

public class PQTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		UnsortedPriorityQueue pq = new UnsortedPriorityQueue(); 
		Process p1 = new Process(1000000);
		Process p2 = new Process(103356600);
		Process p3 = new Process(4560);
		Process p4 = new Process(100);
		Process p5 = new Process(17490);
		pq.add(p1); 
		pq.add(p2); 
		pq.add(p3); 
		pq.add(p4); 
		pq.add(p5); 
		
		while(!pq.isEmpty())		{
			PQEntry entry = pq.removeMin();
			System.out.println(entry);
		}
	}

}
