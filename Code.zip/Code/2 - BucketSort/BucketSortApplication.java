package Lecture_2.BucketSort;

import java.util.ArrayList;

public class BucketSortApplication {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		BucketSort barr = new BucketSort(); 
		//2 ,8 ,3 ,0 ,1
		ArrayList<Integer> list = new ArrayList<Integer>(); 
		list.add(2);  list.add(8); list.add(3); list.add(0); list.add(1);
		barr.setData(list);
		ArrayList<Integer> sorted_list = barr.sort(); 
		for(Integer i:sorted_list)
			System.out.print(i+",");
	}

}
