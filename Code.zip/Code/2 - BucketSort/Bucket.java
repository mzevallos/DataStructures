package Lecture_2.BucketSort;
 
import java.util.*;

public class Bucket {
	private ArrayList<Integer> elements; 
	private int key;
	private int num; //the actual number of elements inside the bucket
	
	/**
	 * Special purpose constructor
	 * @param n : the maximum length of elements that a bucket can store
	 * @param k: the key of the bucket
	 */
	public Bucket(int n , int k){
		elements = new ArrayList<Integer>(); 
		key = k;
	}
	
	/**
	 * 
	 * @param v is an integer element to be added to the bucket. 
	 */
	public void add(int v){
		elements.add(v);
	}
	
	/**
	 * Removes the first occurrence of the input value.
	 * @param v: integer value
	 */
	public boolean remove(int v){
		if (elements == null || elements.size()==0) return false;
		for(int i=0; i<elements.size(); i++){
			if(elements.get(i).equals(v)){
				elements.set(i, null);
				return true; //removing the first occurrence of v 
			}
		}
		return false; // v was not found.
	}
	
	/**
	 * 
	 * @return all elements stored in a bucket
	 */
	public ArrayList<Integer> getElements(){
		return elements;
	}
	
	/**
	 * 
	 * @return the key associated with the bucket
	 */
	public int getKey(){
		return key;
	}
	
	/**
	 * 
	 * @return the number of elements stored in the bucket
	 */
	public int getSize(){
		return num;
	}
	
	
	public void sort(){ //insertion sort
		for(int i =1; i< elements.size(); i++){
			int k = i;
			while(k > 0 && elements.get(k) < (Integer)elements.get(k-1) ){
				int temp = elements.get(k-1); 
				elements.set(k-1, elements.get(k));
				elements.set(k,temp); 
				k--;
			}
		}
	}

}
