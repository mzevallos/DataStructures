package Lecture_2.BucketSort;

import java.util.ArrayList;

public class BucketSort {
	//we need bucket sort to sort digits in the range [0,9]
	private Bucket[] buckets; 
	private static final int DEFAULT_SIZE = 10; //Max number of buckets.
	private int capacity; //actual size of buckets array.
	private ArrayList<Integer> data;
	
	public BucketSort(){
		buckets = new Bucket[DEFAULT_SIZE]; 
		capacity=0; 
	}
	
	public BucketSort(ArrayList data){
		buckets = new Bucket[data.size()]; 
		capacity=0; 
		this.data=data; 
	}
	
	public void setData(ArrayList data){
		this.data=data;
	}
	
	public int getSize(){ return DEFAULT_SIZE; }
	
	
	/**
	 * 
	 * @param key: an int key in the range [0,9]
	 * @param value
	 * @return
	 */
	public boolean add(int key, int value){
		//value is data like 234
		buckets[key] = new Bucket(data.size(), key);
		buckets[key].add(value); 
		return true;
	}
	
	public ArrayList<Integer> getBucketElements(int key){
			return buckets[key].getElements(); 
	}
	
	public Bucket[] getAllBuckets() {
		return buckets; 
	}
	
	
	public ArrayList<Integer> sort(){
		//distribute data into buckets
		for(int i=0;i<data.size();i++){
			add(data.get(i),data.get(i));
		}
		//sort data within each bucket
		for(Bucket b: getAllBuckets()){
			if(b!=null)
				b.sort();
		}
		//read data from buckets
		ArrayList<Integer> partially_sorted_Array= new ArrayList<Integer>(); 
		for(Bucket b: getAllBuckets()){
			if(b!=null)
				partially_sorted_Array.addAll(b.getElements()); 
		}
		data=partially_sorted_Array; 
		return data; 
	}
	
	
	

}
