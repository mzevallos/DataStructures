package RecursionExample1;

public class Tester {
	public static void main(String[] args){
		FractionalPattern.nonRecursiveFractionalPattern(10);
		System.out.println("\n");
		FractionalPattern.recursiveFractionalPattern(10);
	}
}
