

import javax.swing.JOptionPane;

public class Factorial {


	public static void main(String[] args) {
		
		int input = Integer.parseInt(JOptionPane.showInputDialog("Please Enter an Integer")); 
		JOptionPane.showMessageDialog(null, factorial(input), "Unary Recursion--Factorial", 1);
	}
	
	
	//this is an example of "unary recursion"
	public static int factorial(int n){
		if (n<0) return -1;
		if(n==0) return 1;
		return n*factorial(n-1);
	}

}
