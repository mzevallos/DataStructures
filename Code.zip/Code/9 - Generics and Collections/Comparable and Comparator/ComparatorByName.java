import java.util.Comparator;

public class ComparatorByName implements Comparator<Object> {
	public int compare(Object o1, Object o2) {
		if(o1 instanceof Student && o2 instanceof Student ){
			return ((Student)o1).getName().compareToIgnoreCase( ((Student)o2 ).getName());
		}
		return -2;
	}
}