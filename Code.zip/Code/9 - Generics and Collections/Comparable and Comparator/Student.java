
public class Student extends Person implements Comparable<Object>{
	private double gpa; 
	public Student(String name, double gpa) { super(name);   this.gpa = gpa; }
	public Double getGpa() { return this.gpa; }
	public String toString() { return "name: "+ getName() + ", GPA: " + gpa; }
	public int compareTo(Object o) {
		if(! (o instanceof Student)) return -2;
		else {
			Student so= (Student) o; 
			return this.getName().compareToIgnoreCase(so.getName()); 
		}
	}
	@Override
	public String display() { return "Name: " +getName() + "; GPA: " + gpa;}
}
