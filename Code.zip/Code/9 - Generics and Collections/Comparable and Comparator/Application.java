
import java.util.*;
import javax.swing.JOptionPane;
public class Application {
	public static void main(String[] args){
		Set<Person> people= new TreeSet<Person>(new StudentComparator());
		String menu = "1- Add a student, 2- Display, 3- Exit.";
		int option = -1;
		while(true){
			option = Integer.parseInt(JOptionPane.showInputDialog(menu));
			switch(option){
			case 1:
				do{
					people.add(getStudent());
				}while(JOptionPane.showConfirmDialog(null, "Add more?")==JOptionPane.YES_OPTION);
				break;
			case 2:
				displayAll(people);
				break;
			case 3:
				System.exit(0);
				break;
			}
		}
		
	}
	
	public static Person getStudent(){
		return new Student(JOptionPane.showInputDialog("Enter student name") , 
				Double.parseDouble(JOptionPane.showInputDialog("Enter student GPA”)));
	}
	
	public static void displayAll(Set<Person> all){
		Iterator it = all.iterator() ;
		String out= "";
		if (!all.isEmpty()){
			while(it.hasNext()){
				out+= ((Person) it.next()).display() +"\n";
			}
			JOptionPane.showMessageDialog(null, out);
		}
		else JOptionPane.showMessageDialog(null, "The list is empty.");
	}
	

}
