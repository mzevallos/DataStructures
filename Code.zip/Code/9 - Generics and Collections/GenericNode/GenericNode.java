package Lecture10.GenericNode;

public class GenericNode<E> implements Cloneable{
	E data; 
	GenericNode<E> next; 
	
	public GenericNode (E data , GenericNode<E> next){
		this.data = data;
		this.next = next;
	}
	
	public void setNext(GenericNode<E> next){this.next = next;}	
	public E getData(){ return data; }
	public boolean hasNext() { return (next!=null)?true:false; }
	public GenericNode<E> getNext() { return next; }
	
	public GenericNode<E> clone(){
		GenericNode<E> answer; 
		try {
			answer = (GenericNode<E>) super.clone();
		} catch (CloneNotSupportedException e) {
			 throw new RuntimeException ("This class does not implement Cloneable");
		}	
		return answer;	
	}
}
