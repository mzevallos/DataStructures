package Lecture10.GenericNode;

public class Student {
	private String name; 
	private String major; 
	
	public Student(String name, String major) {
		this.name = name; 
		this.major = major;
	}
	
	public String getName() { return this.name; }
	public String getMajor() { return this.major; }
	public String toString() { return "name: "+ name + ", major: " + major; }
}
