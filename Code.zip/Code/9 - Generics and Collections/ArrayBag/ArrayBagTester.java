package Lecture10.ArrayBag;

import java.util.Iterator;

public class ArrayBagTester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayBag<Double> b1 = new ArrayBag<Double>(); 
		b1.add(100.1);
		b1.add(99.6);
		b1.add(50.0);
		b1.add(6.11);
		
		ArrayBag<Double> b2 = new ArrayBag<Double>(); 
		b2.add(100.1);
		b1.add(699.6);
		b1.add(150.0);
		b1.add(86.11);
		
		ArrayBag<Double> b3 = ArrayBag.union(b1, b2);
		Iterator<Double> it = b3.iterator(); 
		while(it.hasNext()) {
			System.out.print(it.next() + ",");
		}
	}

}
