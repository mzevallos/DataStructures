
import java.util.Iterator;
import java.util.TreeSet;
import java.util.Set;


public class TreeSetApplication {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Set<String> coll= new TreeSet<String>(new CompareDescend());
		coll.add("Ab"); 
		coll.add("abc");
		coll.add("zip");
		coll.add("Zebra");
		Iterator it = coll.iterator(); 
		while(it.hasNext()){
			System.out.print(it.next() + ",");
		}
	}

	//outputs
	//Ascendingly : Ab,abc,Zebra,zip,
	//Descendingly: zip,Zebra,abc,Ab,
}
