

import java.util.HashMap;
import java.util.Map;

public class StudentMap {
	public final static int MAX = 100;
	
	
	//public final static String[] COURSE_LIST = {"IT106","IT206" , "IT306","IT212","IT213","IT214","COMM100","MATH112","IT293"};
	public final static String LIST= "IT106,IT206,IT306,IT212,IT213,IT214,COMM100,MATH112,IT293";
	public final static Map<String,String> COURSE_LIST = new HashMap<String, String>();
	static
	{
		COURSE_LIST.put("IT106", "IT106");
		COURSE_LIST.put("IT206", "IT206");
		COURSE_LIST.put("IT306", "IT306");
		COURSE_LIST.put("IT212", "IT212");
		COURSE_LIST.put("IT213", "IT213");
		COURSE_LIST.put("IT214", "IT214");
		COURSE_LIST.put("COMM100", "COMM100");
		COURSE_LIST.put("MATH112", "MATH112");
		COURSE_LIST.put("IT293", "IT293");
	}
	
	
	private String name; 
	private String address; 
	private String major;
	//private double[] courseGrades; 
	//private String[] courses;
	private Map<String, Double> courses;
	private int id; 
	private int numCourses;
	private static int totalStudent; 
	
	public StudentMap(){
		//courseGrades = new double[MAX];
		//courses = new String[MAX];
		totalStudent++; 
		this.id = totalStudent;
		courses = new HashMap<String, Double>();
		this.numCourses = 0;
	}
	public void setName(String name) {this.name = name;}
	public void setAddress(String address) { this.address = address; }
	public void setMajor(String major) {this.major = major; }
	
	public boolean setCourse(double grade, String course){
		if(numCourses >= MAX) return false;
		if(COURSE_LIST.containsKey(course.toUpperCase())) {
			courses.put(course.toUpperCase(), grade);
			numCourses++;
			return true;
		}
		/*
		for(int i=0; i<COURSE_LIST.length; i++){
			if(COURSE_LIST[i].equalsIgnoreCase(course)){
				courseGrades[numCourses]=grade;
				courses[numCourses++]=course;
				return true; 
			}
		}
		*/
		return false;
	}
	
	public String getName() { return name; }
	public String  getAddress(){ return address; }
	public String getMajor(){ return major; }
	public static int getTotalStudents(){ return totalStudent; }
	public int getNumCourses(){ return numCourses;}
	public int getId(){ return id;}
	
	public double getGrade(String course) {
		if(courses.containsKey(course.toUpperCase()))
			return courses.get(course.toUpperCase());
		/*
		for(int i= 0;i<COURSE_LIST.length; i++){
			if(COURSE_LIST[i].equalsIgnoreCase(course)){
				double grade = courseGrades[i]; 
				return grade;
			}
		}
		*/
		
		return -1;
	}

}
