package IT206Assignment2.Example2;

public class Employee {
	double baseSal; 
	
	public Employee(double bsal){
		baseSal = bsal;
	}
	
	
	public String toString(){
		if(this instanceof Director)
			return "Salary: " + ((Director)this).getPromotion();
		else
			return "Salary: " + ((Programmer)this).getPromotion();
	}
	
}
