package IT206Assignment2.Example2;

public class Programmer extends Employee{

	public Programmer(double s){
		super(s);
	}
	
	public double getPromotion(){
		return baseSal+baseSal*.2; 
	}
}
