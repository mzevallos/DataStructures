package IT206Assignment2.Example2;

public class Director extends Employee{
	
	public Director(double s){
		super(s);
	}
	
	public double getPromotion(){
		return baseSal+baseSal*.5; 
	}
}
